package com.example.atividade

class ListaCompromisso private constructor(){

    companion object {

        private var listaCompromisso = mutableListOf<Compromisso>()

        init {
            listaCompromisso.add(
                Compromisso("Evento Anime", "16-09-2023",
                "9h", "18h", "Um evento que vai apresentar os diversos animes que terão estreia em 2024")
            )

            listaCompromisso.add(
                Compromisso("Evento Game", "20-10-2023",
                "13h", "20h", "Vai abordar sobre games da nova geração")
            )
        }


        fun addCopromisso(compromisso: Compromisso){
            listaCompromisso.add(compromisso)
        }

        fun getCompromisso(position: Int) : Compromisso{
            return listaCompromisso[position]
        }

        fun removeCompromisso(position: Int){
            listaCompromisso.removeAt(position)
        }

        fun getListSize() : Int {
            return listaCompromisso.size
        }

    }
}