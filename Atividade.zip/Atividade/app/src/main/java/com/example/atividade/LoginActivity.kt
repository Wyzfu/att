package com.example.atividade

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.atividade.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var dadosLogin: DadosLogin


    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)

        setContentView(binding.root)


        dadosLogin = DadosLogin(applicationContext)


        binding.btnEntrar.setOnClickListener {
            validarCampos()
        }


        binding.btnPrimeiroAcesso.setOnClickListener {
            var intent = Intent( this, CadastroActivity::class.java)
            startActivity(intent)
        }

    }

    override fun onStart() {
        super.onStart()
        if (dadosLogin.getLogado()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun validarCampos() {

        if (camposEmBranco()) {
            Util.exibirToast(this,"Preencha todos os campos!")
            return //encerramos a execução da função
        }

        if (valoresDiferentes()) {
            Util.exibirToast(this, "E-mail ou Senha inválidos!")
            binding.edtEmail.text.clear()
            binding.edtSenha.text.clear()
            return
        }

        if (binding.ckbContinuarLogado.isChecked) {
            dadosLogin.continuarLogado(true)
        }


        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        //matar essa activity
        finish()
    }


    private fun camposEmBranco() : Boolean {
        return binding.edtEmail.text.isEmpty() || binding.edtSenha.text.isEmpty()
    }

    private fun valoresDiferentes() : Boolean {
        return binding.edtEmail.text.toString() != dadosLogin.getEmail() ||
                binding.edtSenha.text.toString() != dadosLogin.getSenha()
    }
}
