package com.example.atividade

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.atividade.databinding.ActivityCadastroBinding
import com.example.aula12.Compromisso

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private lateinit var dadosLogin: DadosLogin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)

        setContentView(binding.root)

        dadosLogin = DadosLogin(this)

        binding.btnCadastrar.setOnClickListener {
            validarDados()
        }
    }

    private fun validarDados() {

        if (binding.edtTitulo.text.isEmpty() ||
            binding.edtData.text.isEmpty() ||
            binding.edtHoraI.text.isEmpty() ||
            binding.edtHoraT.text.isEmpty() ||
            binding.edtDesc.text.isEmpty()
        ) {

            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT)
            return
        }

        if (camposEmBranco()) {
            Util.exibirToast(this, "Preencha todos os campos")
            return
        }

        if (senhasDiferentes()) {
            Util.exibirToast(this, "As senhas não conferem")
            binding.edtNovaSenha.text.clear()
            binding.edtConfirmaSenha.text.clear()
            return
        }

        salvarNovosDados()
        var intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun camposEmBranco(): Boolean {
        return binding.edtNovoEmail.text.isEmpty() ||
                binding.edtNovaSenha.text.isEmpty() ||
                binding.edtConfirmaSenha.text.isEmpty()
    }

    private fun senhasDiferentes(): Boolean {
        return binding.edtNovaSenha.text.toString() !=
                binding.edtConfirmaSenha.text.toString()
    }

    private fun salvarNovosDados() {
        var novoEmail = binding.edtNovoEmail.text.toString()
        var novaSenha = binding.edtNovaSenha.text.toString()
        dadosLogin.salvarDadosLogin(novoEmail, novaSenha)
        Util.exibirToast(this, "Novos dados de login salvos")
    }

    var compromisso = Compromisso(
        binding.edtTitulo.text.toString(),
        binding.edtData.text.toString(),
        binding.edtHoraI.text.toString(),
        binding.edtHoraT.text.toString(),
        binding.edtDesc.text.toString()
    )

    ListaCompromisso.addCompromisso(compromisso)

    var intent = Intent(this, MainActivity::class.java)
    startActivity(intent)
    finish()

}
