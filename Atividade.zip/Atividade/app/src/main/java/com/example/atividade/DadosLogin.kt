package com.example.atividade

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Email

class DadosLogin (context : Context) {

    private var sharedPreferences = context.getSharedPreferences("Login", Context.MODE_PRIVATE)


    fun salvarDadosLogin (email: String, senha : String) {
        sharedPreferences.edit()
            .putString(Util.Constantes.CHAVE_EMAIL,email)
            .putString(Util.Constantes.CHAVE_SENHA,senha)
            .apply()
    }

    fun continuarLogado(valor : Boolean) {
        sharedPreferences.edit()
            .putBoolean(Util.Constantes.CHAVE_LOGADO, valor)
            .apply()
    }

    fun getLogado() : Boolean {
        return sharedPreferences.getBoolean(Util.Constantes.CHAVE_LOGADO, Util.Constantes.LOGADO) ?: false
    }

    fun getEmail() : String{
        return sharedPreferences.getString(Util.Constantes.CHAVE_EMAIL, Util.Constantes.EMAIL_PADRAO) ?: ""

    }

    fun getSenha() : String {
        return sharedPreferences.getString(Util.Constantes.CHAVE_SENHA, Util.Constantes.SENHA_PADRAO) ?:""
    }
}