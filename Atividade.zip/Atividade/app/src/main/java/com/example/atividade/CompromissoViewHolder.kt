package com.example.atividade

import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.w3c.dom.Text

class CompromissoViewHolder (layoutCarro: View) : RecyclerView.ViewHolder(layoutCarro) {
    var txtMarcaModelo = layoutCarro.findViewById<TextView>(R.id.txtMarcaModelo)
}