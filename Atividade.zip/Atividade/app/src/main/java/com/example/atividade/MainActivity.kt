package com.example.atividade

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.atividade.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var carroAdapter: CompromissoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        carroAdapter = CompromissoAdapter(this)
        binding.rcvCompromisso.layoutManager = LinearLayoutManager(this)
        binding.rcvCompromisso.adapter = carroAdapter

        binding.btnAddCompromisso.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }


    }

    override fun onStart() {
        super.onStart()
        CompromissoAdapter.notifyDataSetChanged()
    }
}