package com.example.aula12

data class Compromisso (var titulo: String, var data: String,
                  var horarioI: String,var horarioT: String,var  descricao: String)